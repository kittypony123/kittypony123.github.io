# Core Questions for NHG Regarding Cumulus Implementation

This list distills the essential questions NHG needs clear answers to regarding the ongoing CF.Cumulus implementation, focusing on fundamental risks and unknowns.

1.  **Data Handling & Sensitivity:**
    *   What specific resident data (including sensitive categories) does Cumulus process and store, and precisely where is it located within the Azure environment?

2.  **GDPR Compliance:**
    *   How *specifically* does the current Cumulus design and implementation ensure compliance with GDPR principles (e.g., data minimization, purpose limitation, security measures, resident rights)? Where is this documented?

3.  **Security & Access Control:**
    *   What is the documented security architecture for the Cumulus environment? How is access to data controlled at different layers (network, storage, application)?

4.  **Microsoft Purview Integration:**
    *   What is the concrete technical plan for integrating Cumulus data assets (including lineage) into NHG's Microsoft Purview data catalogue? Who is responsible for implementing this integration, and what are the timelines?

5.  **Documentation:**
    *   What comprehensive technical documentation (architecture, data flows, configurations, operational procedures) exists *today* for the implemented Cumulus solution? Who is responsible for creating and maintaining it?

6.  **Consultant Deliverables & Responsibilities:**
    *   What are the exact, documented deliverables and responsibilities of the external consultants regarding data governance, security implementation, Purview integration, and final technical documentation?

7.  **Operational Handover & Support:**
    *   What is the plan for operational handover to internal NHG teams, including necessary training and ongoing support requirements?

