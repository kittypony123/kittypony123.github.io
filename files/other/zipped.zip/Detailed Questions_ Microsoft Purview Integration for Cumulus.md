# Detailed Questions: Microsoft Purview Integration for Cumulus

This document expands on the core need for clarity regarding Microsoft Purview integration, providing a detailed set of questions for NHG to ask the Cumulus project team and consultants.

**1. Strategy & Ownership:**
*   What is the overall strategy for integrating Cumulus-managed data assets into Microsoft Purview?
*   Who has primary ownership and responsibility for ensuring successful Purview integration (e.g., NHG internal team, specific consultant role)?
*   How does the Purview integration align with NHG's broader data governance strategy and objectives?
*   What are the defined success criteria for the Cumulus-Purview integration?

**2. Scope & Coverage:**
*   Which specific Cumulus data assets (ADLS Gen2 paths, SQL tables, Databricks assets, ADF pipelines, etc.) are in scope for Purview cataloging?
*   Are there any Cumulus data assets explicitly *out* of scope? If so, why?
*   What level of detail is expected in Purview (e.g., technical metadata only, business glossary linking, full lineage)?

**3. Technical Implementation - Scanning & Metadata:**
*   What specific Purview scanning methods will be used for each type of Cumulus data source (e.g., native connectors, APIs)?
*   What authentication mechanisms will Purview use to connect to each source (Managed Identity, Service Principal)?
*   What specific permissions need to be granted to Purview's identity on each data source?
*   How will technical metadata (schemas, data types, descriptions) be captured and ingested into Purview?
*   How will business metadata (owners, stewards, glossary terms, classifications) be applied to Cumulus assets within Purview? Will this be manual curation or automated?
*   How will data classifications (e.g., sensitivity levels) applied within Cumulus be reflected or mapped in Purview?
*   Is Unity Catalog enabled/planned for Databricks within Cumulus? If not, what is the alternative strategy for robust Databricks metadata and lineage capture?

**4. Technical Implementation - Lineage:**
*   What is the specific technical approach for capturing end-to-end data lineage for data flowing through Cumulus components (e.g., ADF -> ADLS -> Databricks -> SQL)?
*   Which tools/services within the Cumulus stack will provide lineage information to Purview (e.g., ADF reporting, Unity Catalog lineage, custom parsing)?
*   How will lineage be captured for transformations occurring within custom code (e.g., complex Spark notebooks, SQL procedures)?
*   Are there known gaps in automated lineage capture, and what is the plan to address them (e.g., manual lineage assertion in Purview)?

**5. Timelines & Resources:**
*   What is the detailed timeline for implementing the Purview integration for Cumulus assets?
*   What resources (personnel, time) have been allocated by the project team/consultants for this integration work?
*   What dependencies exist for the Purview integration (e.g., environment access, permissions setup, specific Cumulus configurations)?

**6. Documentation & Handover:**
*   Where will the Purview integration design, configuration steps, and scanning schedules be documented?
*   What knowledge transfer is planned to enable NHG internal staff (like the Data Catalogue Analyst) to manage and maintain the Purview integration for Cumulus post-implementation?

**7. Ongoing Maintenance:**
*   What is the process for updating Purview scans and metadata when Cumulus data structures or pipelines change?
*   Who is responsible for ongoing monitoring of Purview scan success and data accuracy for Cumulus assets?

