# Expert Guidance: Data Governance & Cataloging for Cumulus at NHG (Addressing Workplace Dynamics)

Drawing on data governance and cataloging expertise, here is additional strategic guidance for you as the Data Catalogue Technical Analyst navigating the Cumulus implementation at NHG, specifically addressing the challenging workplace dynamics (low visibility, poor collaboration, overstretched management, '100 cooks', reliance on consultants):

**1. Prioritize Ruthlessly (Strategic Necessity in Chaos):**
*   **Focus on Critical Data:** In a chaotic environment, trying to boil the ocean is impossible. *Hyper-prioritize* the absolute most critical data assets (sensitive resident PII, key financial/operational data). Getting even *one* critical area under governance in Purview is a win.
*   **Map to Visible Business Pain Points:** Link your cataloging efforts directly to problems management *already* cares about (e.g., GDPR risk mentioned in audits, specific reports known to be unreliable). Frame Purview as part of the *solution* to *their* problems.

**2. Leverage Purview as a Tool for Clarity & Influence:**
*   **Purview as the "Single Source of Truth" (Aspirational):** Position Purview not just as a catalog, but as a tool to *create* the visibility and shared understanding that is currently lacking. Frame your requests as helping *everyone* get clarity.
*   **Advocate for Unity Catalog (Strategic Imperative):** Given the lack of clarity, the automated lineage and governance from Unity Catalog becomes even *more* critical. Frame its adoption not just as a technical benefit, but as a way to *reduce reliance on manual documentation and consultant knowledge* that may be unreliable or unavailable.
*   **Make Data Tangible:** Once you have *any* data in Purview, use its features (visual lineage, glossary links, classifications) to create simple reports or demos. Show, don't just tell, management and potential allies what visibility looks like and why it matters.

**3. Navigate the Stakeholder Maze Tactically (Survival Guide):**
*   **Identify Your Single Point of Contact (SPOC) & Allies:** In the '100 cooks' kitchen, trying to please everyone leads to paralysis. Focus 80% of your influencing effort on your identified SPOC and the 1-2 allies who seem most receptive or have relevant responsibilities (e.g., security, compliance lead).
*   **Formal Channels are Your Friend:** When informal collaboration fails (which is likely in a poor collaboration environment), pivot quickly to formal channels. Document *every* request for information via email. Use official project tracking tools if they exist. If necessary, log risks through formal risk management channels. This creates a paper trail and leverages official processes.
*   **Translate Needs into "What's In It For Them?":** Frame requests around how Purview helps *them*. Examples: "Making this data discoverable in Purview will save *your team* time finding it later." "Documenting lineage helps *us all* troubleshoot issues faster." "Classifying sensitive data helps protect *the project* from compliance breaches."
*   **Manage Upwards Concisely:** Respect overstretched management's time. Use the key points previously developed. Focus on **blockers, risks, and required decisions/support**. Offer clear, simple options. Quantify the risk of inaction (e.g., "Delaying cataloging increases GDPR risk exposure daily").

**4. Embrace Iteration & "Good Enough" Governance:**
*   **Start Small, Show Value (Quick Wins):** Focus on achieving one small, visible success (e.g., cataloging one critical source system feeding Cumulus). This builds credibility and demonstrates value quickly, which is vital when attention spans are short.
*   **Perfection is the Enemy of Progress:** In this environment, aiming for a perfect, fully curated catalog initially is unrealistic. Focus on getting the *foundational* technical metadata and critical classifications in place first. Curation can be iterative.

**5. Documentation & Consultant Management (Holding Feet to the Fire):**
*   **Documentation as a Contractual Obligation:** Insist that adequate technical documentation (schemas, lineage details, architecture) is a *deliverable* from the consultants, ideally specified in the SOW. If it's not, raise this as a major project risk to management – NHG is paying for a solution it won't understand or be able to govern independently.
*   **Specific, Written Information Requests:** Provide consultants with *written*, specific lists of the technical information needed (use your checklist). Avoid verbal requests that can be forgotten or misinterpreted. Set reasonable deadlines for responses.
*   **Verify Consultant Information:** Given the lack of internal clarity, critically review information provided by consultants. If possible, request read-only access to verify configurations or data flows yourself. Don't assume consultant information is complete or accurate.
*   **Mandate Knowledge Transfer:** Explicitly request and schedule knowledge transfer sessions from consultants to internal staff (including you) *before* they disengage. Document attendance and topics covered. Frame this to management as essential for reducing long-term dependency and cost.

**6. Protect Your Time & Focus:**
*   **Be Realistic:** Acknowledge the limitations imposed by the environment. Focus your efforts where they can have the most impact (critical data, key allies, management communication).
*   **Document Your Efforts:** Keep a clear log of your requests, who you spoke to, the responses (or lack thereof), and the resulting impact (e.g., "Blocked from cataloging Asset X due to lack of schema info from Consultant Y since [Date]"). This protects you and provides evidence if escalation is needed.

